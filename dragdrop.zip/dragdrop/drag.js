console.log("working");

const boxAll = document.querySelectorAll(".box");
const dragimg = document.querySelector("#dragimg");
const resetbtn = document.querySelector(".resetbtn");

// events
////////////////////////////////////////////////////////////////////
dragimg.addEventListener("dragstart", function () {
  console.log("drag start initiate working");
});

dragimg.addEventListener("dragend", function () {
  console.log("drag end initiate working");
});


resetbtn.addEventListener('click', function(){
  boxAll[0].append(dragimg);
})

for (var i = 0; i < boxAll.length; i++) {
  boxAll[i].addEventListener("dragover", function (e) {
    e.preventDefault();
    console.log("dragover");
  });

  boxAll[i].addEventListener("drop", function (f) {
    f.target.append(dragimg);
    alert("Successfully Dragged")
  });
}
